# GGS Unity project

This is the Unity version of GGS: Day & Night. It uses one C# script that creates the whole user interface at runtime, so you do not need to place buttons or cards by hand in the Unity editor.

## Open and run it

1. Extract the ZIP file if you downloaded one.
2. Open **Unity Hub**.
3. Click **Add**, then select the `GGS-Unity` folder.
4. Open the project with the included Unity version, **6000.5.4f1**, or a newer Unity 6 release.
5. In the Project panel, open `Assets/Scenes/Main`.
6. Press the Play triangle at the top of Unity.

## What the project includes

- Player versus computer card match
- Day/Night rules and Flip-card colour selection
- Skip, Draw 2, No Mercy, deck recycling and score counters
- A landscape Unity UI that fits the default Unity Game view and PC screen

## The important script

`Assets/Scripts/GgsGame.cs` holds the complete game. The three methods to study are next to each other:

- `CanPlay` checks whether a move follows the rules.
- `ApplyEffect` applies Skip and Draw 2 rules for Day and Night.
- `Play` controls each turn.

## Android build later

In Unity, choose **File > Build Profiles**, install Android support if Unity asks, select Android, then click **Build**. Unity produces an APK that you can transfer to your Android phone for testing.
