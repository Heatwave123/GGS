using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

// The game controller. Keep CanPlay, ApplyEffect and Play together: they form the rule engine.
public class GgsGame : MonoBehaviour
{
    public enum Mode { Day, Night }
    private enum Owner { Player, Computer }

    // Public because the UI receives card lists when it draws the player's hand.
    public class Card
    {
        public string color, value, type;
        public Card(string color, string value, string type) { this.color = color; this.value = value; this.type = type; }
    }

    private readonly string[] colors = { "Red", "Blue", "Green", "Yellow" };
    private List<Card> deck = new List<Card>();
    private List<Card> player = new List<Card>();
    private List<Card> computer = new List<Card>();
    private List<Card> discard = new List<Card>();
    private Mode mode;
    private string activeColor;
    private Owner turn;
    private bool ended, noMercy;
    private int playerScore, computerScore;
    private GgsUi ui;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void CreateGame()
    {
        if (FindFirstObjectByType<GgsGame>() == null) new GameObject("GGS Game").AddComponent<GgsGame>();
    }

    private void Awake()
    {
        // A Screen Space Overlay Canvas does not need a camera, but Unity's Game view does.
        // This removes Unity's distracting "No cameras rendering" notice.
        if (FindFirstObjectByType<Camera>() == null)
        {
            Camera camera = new GameObject("Main Camera").AddComponent<Camera>();
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = new Color(.06f, .14f, .12f);
            camera.gameObject.tag = "MainCamera";
        }
        ui = gameObject.AddComponent<GgsUi>();
        ui.Build(this);
        StartRound();
    }

    public void StartRound()
    {
        CancelInvoke();
        deck = MakeDeck(); player.Clear(); computer.Clear(); discard.Clear();
        mode = Mode.Day; turn = Owner.Player; ended = false;
        Draw(player, 7); Draw(computer, 7);
        Card opening;
        do { opening = deck[deck.Count - 1]; deck.RemoveAt(deck.Count - 1); deck.Insert(0, opening); } while (opening.type != "number");
        deck.RemoveAt(0); discard.Add(opening); activeColor = opening.color;
        Message("Your turn. Match the colour, number, or action.");
        Refresh();
    }

    public void ResetScores()
    {
        playerScore = computerScore = 0;
        Message("Scores reset. Start a new round when ready.");
        Refresh();
    }

    public void SetNoMercy(bool enabled) { noMercy = enabled; }
    public void DrawPlayerCard()
    {
        if (ended || turn != Owner.Player) return;
        Draw(player, 1);
        Card drawn = player[player.Count - 1];
        if (noMercy || !CanPlay(drawn))
        {
            turn = Owner.Computer; Message("You draw a card. Computer's turn."); Refresh(); Invoke(nameof(ComputerMove), .65f);
        }
        else { Message("You drew a playable card. Play it, or use another matching card."); Refresh(); }
    }

    public void PlayPlayerCard(int index) { if (turn == Owner.Player) Play(Owner.Player, index); }
    public void ChooseFlipColour(string color)
    {
        activeColor = color; mode = mode == Mode.Day ? Mode.Night : Mode.Day; turn = Owner.Computer;
        ui.HideColourPicker(); Message("The deck flips to " + mode + ". Active colour: " + color + ". Computer's turn.");
        Refresh(); Invoke(nameof(ComputerMove), .65f);
    }

    // Rule engine: a card may match the active colour, the previous value, or be a Flip card.
    private bool CanPlay(Card card)
    {
        Card top = discard[discard.Count - 1];
        return card.type == "flip" || card.color == activeColor || (top.type != "flip" && card.value == top.value);
    }

    // Rule engine: true means the opponent loses their turn.
    private bool ApplyEffect(Card card, List<Card> nextHand, string nextName)
    {
        if (card.value == "SKIP")
        {
            if (mode == Mode.Day) { Message(nextName + " loses a turn."); return true; }
            Draw(nextHand, 1); Message("Night Skip becomes Draw 1. " + nextName + " draws and loses a turn."); return true;
        }
        if (card.value == "+2")
        {
            if (mode == Mode.Day) { Draw(nextHand, 2); Message(nextName + " draws 2 cards and loses a turn."); return true; }
            Message("Night +2 becomes Skip. " + nextName + " loses a turn."); return true;
        }
        return false;
    }

    // Rule engine: removes the card, checks the win state, applies action effects and changes turn.
    private void Play(Owner who, int index)
    {
        if (ended || who != turn) return;
        List<Card> hand = who == Owner.Player ? player : computer;
        List<Card> otherHand = who == Owner.Player ? computer : player;
        string nextName = who == Owner.Player ? "Computer" : "You";
        Card card = hand[index];
        if (!CanPlay(card)) { Message("That card does not match the play pile."); return; }
        hand.RemoveAt(index); discard.Add(card);
        if (hand.Count == 0) { Finish(who); return; }
        if (card.type == "flip")
        {
            if (who == Owner.Player) { Message("Choose the new active colour."); Refresh(); ui.ShowColourPicker(); return; }
            activeColor = BestColour(computer); mode = mode == Mode.Day ? Mode.Night : Mode.Day; turn = Owner.Player;
            Message("Computer flips to " + mode + ". Active colour: " + activeColor + ". Your turn."); Refresh(); return;
        }
        activeColor = card.color;
        bool skip = ApplyEffect(card, otherHand, nextName);
        turn = skip ? who : (who == Owner.Player ? Owner.Computer : Owner.Player);
        Refresh();
        if (turn == Owner.Computer) Invoke(nameof(ComputerMove), .65f);
    }

    private void ComputerMove()
    {
        if (ended || turn != Owner.Computer) return;
        int index = computer.FindIndex(CanPlay);
        if (index >= 0) { Play(Owner.Computer, index); return; }
        Draw(computer, 1);
        int drawnIndex = computer.Count - 1;
        if (!noMercy && CanPlay(computer[drawnIndex])) { Refresh(); Invoke(nameof(PlayDrawnComputerCard), .5f); return; }
        turn = Owner.Player; Message("Computer cannot play. Your turn."); Refresh();
    }
    private void PlayDrawnComputerCard() { Play(Owner.Computer, computer.Count - 1); }

    private List<Card> MakeDeck()
    {
        List<Card> cards = new List<Card>();
        foreach (string color in colors)
        {
            for (int number = 0; number <= 9; number++) cards.Add(new Card(color, number.ToString(), "number"));
            for (int i = 0; i < 2; i++) { cards.Add(new Card(color, "SKIP", "action")); cards.Add(new Card(color, "+2", "action")); }
        }
        for (int i = 0; i < 4; i++) cards.Add(new Card("Flip", "FLIP", "flip"));
        return cards.OrderBy(_ => UnityEngine.Random.value).ToList();
    }
    private void Draw(List<Card> hand, int amount)
    {
        for (int i = 0; i < amount; i++)
        {
            if (deck.Count == 0) Recycle();
            if (deck.Count > 0) { hand.Add(deck[deck.Count - 1]); deck.RemoveAt(deck.Count - 1); }
        }
    }
    private void Recycle()
    {
        if (discard.Count < 2) return;
        Card top = discard[discard.Count - 1]; discard.RemoveAt(discard.Count - 1);
        deck = discard.OrderBy(_ => UnityEngine.Random.value).ToList(); discard = new List<Card> { top };
    }
    private string BestColour(List<Card> hand) => colors.OrderByDescending(color => hand.Count(card => card.color == color)).First();
    private int HandPoints(List<Card> hand) => hand.Sum(card => card.type == "number" ? int.Parse(card.value) : card.type == "flip" ? 50 : 20);
    private void Finish(Owner winner)
    {
        ended = true; int earned = HandPoints(winner == Owner.Player ? computer : player);
        if (winner == Owner.Player) playerScore += earned; else computerScore += earned;
        Message((winner == Owner.Player ? "You win GGS!" : "Computer wins this round.") + " +" + earned + " points."); Refresh(); ui.ShowWinner(winner == Owner.Player ? "You win GGS!" : "Computer wins this round.", earned);
    }
    private void Message(string text) { ui?.SetMessage(text); }
    private void Refresh() { ui?.Refresh(mode.ToString(), activeColor, turn == Owner.Player, player.Count, computer.Count, playerScore, computerScore, player, discard[discard.Count - 1], CanPlay); }

    public class GgsUi : MonoBehaviour
    {
        private GgsGame game; private Font font; private Text message, modeText, colourText, turnText, computerText, playerScoreText, computerScoreText, pileText; private Transform hand, canvasTransform; private GameObject colourPanel, winnerPanel;
        public void Build(GgsGame controller)
        {
            game = controller; font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            if (FindFirstObjectByType<EventSystem>() == null) new GameObject("Event System", typeof(EventSystem), typeof(StandaloneInputModule));
            GameObject canvas = new GameObject("GGS Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            canvasTransform = canvas.transform; Canvas c = canvas.GetComponent<Canvas>(); c.renderMode = RenderMode.ScreenSpaceOverlay; CanvasScaler scaler = canvas.GetComponent<CanvasScaler>(); scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize; scaler.referenceResolution = new Vector2(1920, 1080);
            Image background = canvas.AddComponent<Image>(); background.color = new Color(.06f, .14f, .12f);
            GameObject rootObject = Panel(canvas.transform, new Color(0, 0, 0, 0), 24); RectTransform rootRect = rootObject.GetComponent<RectTransform>(); rootRect.anchorMin = Vector2.zero; rootRect.anchorMax = Vector2.one; rootRect.offsetMin = rootRect.offsetMax = Vector2.zero;
            VerticalLayoutGroup root = rootObject.AddComponent<VerticalLayoutGroup>(); root.padding = new RectOffset(25, 25, 25, 25); root.spacing = 7; root.childControlWidth = true; root.childControlHeight = false;
            Label(root.transform, "GGS: DAY & NIGHT", 30, new Color(1f, .82f, .3f));
            Label(root.transform, "Match. Flip. Outsmart.", 42, Color.white);
            modeText = Label(root.transform, "", 24, Color.white); colourText = Label(root.transform, "", 24, Color.white); turnText = Label(root.transform, "", 24, Color.white); computerText = Label(root.transform, "", 22, Color.white);
            HorizontalLayoutGroup controls = Panel(root.transform, new Color(.12f, .3f, .24f, 1), 12).AddComponent<HorizontalLayoutGroup>(); controls.spacing = 8; Button(controls.transform, "New round", new Color(.15f,.42f,.32f), game.StartRound, -1, 54); Button(controls.transform, "Reset scores", new Color(.25f,.25f,.28f), game.ResetScores, -1, 54);
            Toggle toggle = Toggle(controls.transform, "No Mercy"); toggle.onValueChanged.AddListener(game.SetNoMercy);
            computerScoreText = Label(root.transform, "", 26, new Color(1f,.87f,.45f));
            Button(root.transform, "DRAW CARD", new Color(.8f,.3f,.28f), game.DrawPlayerCard, -1, 54);
            pileText = Label(root.transform, "PLAY PILE", 24, new Color(.75f,.9f,.82f));
            hand = Panel(root.transform, new Color(0,0,0,0), 4).transform; HorizontalLayoutGroup cards = hand.gameObject.AddComponent<HorizontalLayoutGroup>(); cards.spacing = 8; cards.childAlignment = TextAnchor.MiddleCenter; cards.childControlWidth = false; cards.childControlHeight = false; cards.childForceExpandWidth = false;
            message = Label(root.transform, "", 22, new Color(1f,.92f,.65f)); message.alignment = TextAnchor.MiddleCenter;
            playerScoreText = Label(root.transform, "", 26, new Color(1f,.87f,.45f));
            colourPanel = Overlay("Choose the active colour"); foreach (string color in new[] { "Red", "Blue", "Green", "Yellow" }) { string choice = color; Button(colourPanel.transform, color, CardColor(color), () => game.ChooseFlipColour(choice)); } colourPanel.SetActive(false);
            winnerPanel = Overlay(""); Button(winnerPanel.transform, "Play another round", new Color(.15f,.42f,.32f), () => { winnerPanel.SetActive(false); game.StartRound(); }); winnerPanel.SetActive(false);
        }
        public void Refresh(string mode, string color, bool playerTurn, int playerCards, int computerCards, int playerScore, int computerScore, List<Card> playerHand, Card top, Func<Card,bool> canPlay)
        {
            modeText.text = "MODE: " + mode.ToUpper(); colourText.text = "ACTIVE COLOUR: " + color.ToUpper(); turnText.text = playerTurn ? "YOUR TURN" : "COMPUTER THINKING"; computerText.text = "COMPUTER CARDS: " + computerCards; playerScoreText.text = "YOUR SCORE: " + playerScore; computerScoreText.text = "COMPUTER SCORE: " + computerScore; pileText.text = "PLAY PILE: " + CardLabel(top);
            foreach (Transform child in hand) Destroy(child.gameObject);
            for (int i = 0; i < playerHand.Count; i++) { int index = i; Card card = playerHand[i]; Button(hand, CardLabel(card), CardColor(card.color), () => game.PlayPlayerCard(index), 95, 108); }
        }
        public void SetMessage(string text) { if (message != null) message.text = text; }
        public void ShowColourPicker() { colourPanel.SetActive(true); }
        public void HideColourPicker() { colourPanel.SetActive(false); }
        public void ShowWinner(string title, int points) { Text label = winnerPanel.GetComponentInChildren<Text>(); label.text = title + "\n+" + points + " points"; winnerPanel.SetActive(true); }
        private GameObject Overlay(string label)
        {
            GameObject panel = Panel(canvasTransform, new Color(.03f,.05f,.08f,.96f), 22); RectTransform r = panel.GetComponent<RectTransform>(); r.anchorMin = new Vector2(.1f,.25f); r.anchorMax = new Vector2(.9f,.75f); r.offsetMin = r.offsetMax = Vector2.zero; VerticalLayoutGroup layout = panel.AddComponent<VerticalLayoutGroup>(); layout.padding = new RectOffset(34,34,34,34); layout.spacing = 18; Label(panel.transform, label, 42, Color.white); return panel;
        }
        private GameObject Panel(Transform parent, Color color, int minHeight) { GameObject panel = new GameObject("Panel", typeof(RectTransform), typeof(Image), typeof(LayoutElement)); panel.transform.SetParent(parent, false); panel.GetComponent<Image>().color = color; panel.GetComponent<LayoutElement>().minHeight = minHeight; return panel; }
        private Text Label(Transform parent, string text, int size, Color color) { GameObject obj = new GameObject("Text", typeof(RectTransform), typeof(Text), typeof(LayoutElement)); obj.transform.SetParent(parent, false); Text t = obj.GetComponent<Text>(); t.font = font; t.text = text; t.fontSize = size; t.color = color; t.alignment = TextAnchor.MiddleCenter; obj.GetComponent<LayoutElement>().minHeight = size + 18; return t; }
        private Button Button(Transform parent, string text, Color color, UnityEngine.Events.UnityAction action, float width = -1, float height = 72) { GameObject obj = new GameObject("Button", typeof(RectTransform), typeof(Image), typeof(Button), typeof(LayoutElement)); obj.transform.SetParent(parent, false); obj.GetComponent<Image>().color = color; LayoutElement le = obj.GetComponent<LayoutElement>(); le.preferredWidth = width; le.preferredHeight = height; Button b = obj.GetComponent<Button>(); b.onClick.AddListener(action); Text label = Label(obj.transform, text, 25, Color.white); label.resizeTextForBestFit = true; label.resizeTextMinSize = 14; return b; }
        private Toggle Toggle(Transform parent, string text) { GameObject obj = new GameObject("Toggle", typeof(RectTransform), typeof(Toggle), typeof(LayoutElement)); obj.transform.SetParent(parent, false); obj.GetComponent<LayoutElement>().preferredHeight = 54; Toggle t = obj.GetComponent<Toggle>(); GameObject bg = Panel(obj.transform, Color.white, 32); RectTransform br = bg.GetComponent<RectTransform>(); br.anchorMin = new Vector2(0,.25f); br.anchorMax = new Vector2(.18f,.75f); br.offsetMin=br.offsetMax=Vector2.zero; GameObject check = Panel(bg.transform, new Color(.95f,.65f,.2f), 20); RectTransform cr=check.GetComponent<RectTransform>(); cr.anchorMin=Vector2.zero;cr.anchorMax=Vector2.one;cr.offsetMin=cr.offsetMax=new Vector2(5,5); t.targetGraphic=bg.GetComponent<Image>();t.graphic=check.GetComponent<Image>(); Label(obj.transform,text,18,Color.white).alignment=TextAnchor.MiddleRight; return t; }
        private Color CardColor(string color) { switch(color) { case "Red": return new Color(.82f,.25f,.25f); case "Blue": return new Color(.2f,.43f,.75f); case "Green": return new Color(.22f,.57f,.37f); case "Yellow": return new Color(.82f,.65f,.15f); default: return new Color(.4f,.26f,.7f); } }
        private string CardLabel(Card card) { return card.type == "flip" ? "◐\nFLIP" : card.value; }
    }
}
